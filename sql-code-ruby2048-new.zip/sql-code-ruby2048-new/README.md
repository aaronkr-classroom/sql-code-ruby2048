# 2024-sql-code

Repository to collect all SQL files for DJU-DB.

- `/code` = 실습 코드 제출
- `/data` = SQL을 위한 데이터
- `/exercises` = 연습 문제
